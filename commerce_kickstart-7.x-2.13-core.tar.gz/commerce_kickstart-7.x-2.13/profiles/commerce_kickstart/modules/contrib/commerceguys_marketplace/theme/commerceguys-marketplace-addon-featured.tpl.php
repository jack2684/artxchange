<div class="marketplace-addon-featured" xmlns="http://www.w3.org/1999/html">
  <a href="<?php print $path;?>" target="_blank">
    <?php print $logo; ?>
    <div class="addon-overlay">
      <div class="title"><?php print $title;?></div>
      <div class="tagline"><?php print $tagline;?></div>
      <div class="category"><?php print $category;?></div>
    </div>
  </a>
</div>
