<div class="marketplace-list-item-image">
  <?php print $logo; ?>
</div>
<div class="marketplace-list-item-info">
  <div class="title"><?php print $title; ?></div>
  <div class="tagline"><?php print $tagline;?></div>
  <div class="more"><?php print $more_link; ?></div>
</div>
